# WhatsApp AI System - RBL FACTA

Sistema completo de atendimento automatizado via WhatsApp com IA, integração bancária e campanhas inteligentes.

## 🎯 Funcionalidades

### ✅ **Atendimento IA 24/7**
- Agente IA seguindo padrão da Thaiza Vianna
- Resposta instantânea e conversão otimizada
- Memória de contexto e escalação inteligente

### ✅ **Integração Bancária Automatizada**
- IA digita propostas automaticamente no sistema do banco
- Processo 100% automatizado
- Logs e auditoria completos

### ✅ **Sistema de Campanhas**
- Agendamento inteligente (7h-20h, seg-sex)
- Limite de mensagens por período
- Múltiplas campanhas simultâneas

### ✅ **Gestão de Contatos**
- Upload de planilhas (.csv/.xlsx)
- Segmentação automática
- Deduplicação e validação

## 🏗️ Arquitetura

```
├── backend/          # API Node.js + Express
├── frontend/         # Dashboard React.js
├── database/         # Schema PostgreSQL
├── docs/            # Documentação
└── scripts/         # Scripts de automação
```

## 🚀 Tecnologias

- **Backend**: Node.js, Express, PostgreSQL, Redis
- **Frontend**: React.js, TypeScript, Tailwind CSS
- **IA**: OpenAI GPT-4
- **WhatsApp**: 360Dialog API
- **Automação**: Puppeteer
- **Deploy**: Docker, AWS/DigitalOcean

## 📋 Pré-requisitos

- Node.js 18+
- PostgreSQL 14+
- Redis 6+
- Conta 360Dialog
- Chave OpenAI API

## ⚡ Instalação Rápida

### 1. Clone o repositório
```bash
git clone <repository-url>
cd whatsapp-ai-system
```

### 2. Configure o backend
```bash
cd backend
npm install
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

### 3. Configure o banco de dados
```bash
# Crie o banco PostgreSQL
createdb whatsapp_ai

# Execute as migrações
npm run migrate
```

### 4. Inicie o servidor
```bash
npm run dev
```

### 5. Configure o frontend (em outro terminal)
```bash
cd ../frontend
npm install
npm start
```

## 🔧 Configuração

### Variáveis de Ambiente (.env)

```env
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=whatsapp_ai
DB_USER=postgres
DB_PASSWORD=your_password

# WhatsApp (360Dialog)
WHATSAPP_API_KEY=your_360dialog_api_key
WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id

# OpenAI
OPENAI_API_KEY=your_openai_api_key

# JWT
JWT_SECRET=your_super_secret_key
```

### 360Dialog Setup

1. Criar conta em [360Dialog](https://360dialog.com)
2. Solicitar número WhatsApp Business
3. Obter credenciais da API
4. Configurar webhook: `https://your-domain.com/api/whatsapp/webhook`

## 📊 Uso

### Dashboard Administrativo

Acesse `http://localhost:3001` com:
- **Email**: admin@rbl.com
- **Senha**: admin123

### Funcionalidades Principais

1. **Gestão de Contatos**
   - Upload de planilhas
   - Segmentação automática
   - Histórico de interações

2. **Criação de Campanhas**
   - Definir audiência
   - Agendar envios
   - Monitorar resultados

3. **Configuração da IA**
   - Ajustar respostas
   - Treinar com novos dados
   - Logs de conversas

4. **Relatórios**
   - Taxa de conversão
   - Performance de campanhas
   - Analytics detalhados

## 🤖 Configuração da IA

### Padrão Thaiza Vianna

O sistema replica exatamente o padrão de atendimento da Thaiza:

```javascript
// 10 Etapas de Atendimento
1. Apresentação inicial ou follow-up
2. Processo de autorização no app FGTS
3. Coleta de CPF e data nascimento
4. Apresentação do resultado com entusiasmo
5. Confirmação/coleta de dados bancários
6. Geração do link de saque
7. Solicitação de prioridade na análise
8. Finalização com agradecimento
9. Campanha de indicação
10. Oferta de consignado (opcional)
```

### Frases Exatas
- "Boas notícias!!!! Disponível para recebimento o valor de: *R$ [valor]*"
- "Vamos dar andamento ao saque? 🤩"
- "Um momento, por favor, que vou gerar o link de saque 👩‍💻"

## 🔗 API Endpoints

### Autenticação
- `POST /api/auth/login` - Login
- `POST /api/auth/register` - Registro (Admin)
- `GET /api/auth/me` - Usuário atual

### WhatsApp
- `POST /api/whatsapp/webhook` - Webhook
- `POST /api/whatsapp/send` - Enviar mensagem

### Campanhas
- `GET /api/campaigns` - Listar campanhas
- `POST /api/campaigns` - Criar campanha

### Contatos
- `GET /api/contacts` - Listar contatos
- `POST /api/contacts/upload` - Upload de contatos

### IA
- `POST /api/ai/chat` - Processar chat
- `GET /api/ai/conversations` - Histórico

### Banco
- `POST /api/bank/submit-proposal` - Submeter proposta
- `GET /api/bank/integrations` - Histórico de integrações

## 📈 Monitoramento

### Logs
- `backend/logs/combined.log` - Logs gerais
- `backend/logs/error.log` - Logs de erro

### Métricas
- Taxa de conversão
- Tempo de resposta
- Volume de mensagens
- Performance da IA

## 🚀 Deploy

### Docker
```bash
docker-compose up -d
```

### Manual
1. Configure servidor (Ubuntu 20.04+)
2. Instale dependências
3. Configure nginx
4. Configure SSL
5. Execute aplicação

## 🔒 Segurança

- JWT para autenticação
- Rate limiting
- Validação de dados
- Logs de auditoria
- Criptografia de dados sensíveis

## 📞 Suporte

Para suporte técnico:
- Email: suporte@rbl.com
- Documentação: `/docs`
- Issues: GitHub Issues

## 📄 Licença

MIT License - veja LICENSE.md para detalhes.

---

**Desenvolvido por RBL FACTA Team** 🚀

