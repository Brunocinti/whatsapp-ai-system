#!/bin/bash

# WhatsApp AI System - Railway Deploy Script
# RBL FACTA

set -e

echo "🚀 WhatsApp AI System - Railway Deploy"
echo "======================================"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if Railway CLI is installed
if ! command -v railway &> /dev/null; then
    print_warning "Railway CLI not found. Installing..."
    npm install -g @railway/cli
fi

print_step "1. Preparing for deployment..."

# Create .railwayignore
cat > .railwayignore <<EOF
node_modules
.git
.env
*.log
logs/
frontend/
docs/
scripts/
.gitignore
README.md
docker-compose.yml
Dockerfile
EOF

print_status "Created .railwayignore"

# Update package.json for Railway
cd backend
if ! grep -q '"engines"' package.json; then
    # Add engines field to package.json
    node -e "
    const pkg = require('./package.json');
    pkg.engines = { node: '>=18.0.0', npm: '>=8.0.0' };
    require('fs').writeFileSync('package.json', JSON.stringify(pkg, null, 2));
    "
    print_status "Added engines to package.json"
fi

cd ..

print_step "2. Login to Railway..."
railway login

print_step "3. Create new Railway project..."
railway init

print_step "4. Add PostgreSQL database..."
railway add --database postgresql

print_step "5. Add Redis..."
railway add --database redis

print_step "6. Setting environment variables..."

# Set environment variables
railway variables set NODE_ENV=production
railway variables set PORT=3000
railway variables set JWT_SECRET=$(openssl rand -base64 32)

# OpenAI API Key
if [ -n "$OPENAI_API_KEY" ]; then
    railway variables set OPENAI_API_KEY="$OPENAI_API_KEY"
    print_status "OpenAI API key set from environment"
else
    print_warning "Please set OPENAI_API_KEY manually in Railway dashboard"
fi

# WhatsApp variables (to be set later)
railway variables set WHATSAPP_API_URL="https://waba.360dialog.io"
railway variables set WHATSAPP_WEBHOOK_SECRET=$(openssl rand -base64 16)

print_warning "Remember to set these variables in Railway dashboard:"
echo "- WHATSAPP_API_KEY"
echo "- WHATSAPP_PHONE_NUMBER_ID"

print_step "7. Deploy to Railway..."
railway up

print_step "8. Run database migration..."
railway run npm run migrate

print_status "Deployment completed! 🎉"

# Get the deployment URL
RAILWAY_URL=$(railway status --json | jq -r '.deployments[0].url' 2>/dev/null || echo "Check Railway dashboard")

echo ""
echo "============================================="
echo "🎉 Deployment Successful!"
echo "============================================="
echo ""
echo "📱 Your WhatsApp AI System is live at:"
echo "🌐 $RAILWAY_URL"
echo ""
echo "📋 Next steps:"
echo "1. Set WhatsApp API credentials in Railway dashboard"
echo "2. Configure 360Dialog webhook URL: $RAILWAY_URL/api/whatsapp/webhook"
echo "3. Test the system with: $RAILWAY_URL/health"
echo ""
echo "🔑 Default admin login:"
echo "Email: admin@rbl.com"
echo "Password: admin123"
echo ""
print_status "Happy deploying! 🚀"

