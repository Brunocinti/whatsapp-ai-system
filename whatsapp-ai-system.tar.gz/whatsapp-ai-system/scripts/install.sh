#!/bin/bash

# WhatsApp AI System - Installation Script
# RBL FACTA

set -e

echo "🚀 WhatsApp AI System - Installation Script"
echo "============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "This script should not be run as root"
   exit 1
fi

# Check OS
if [[ "$OSTYPE" != "linux-gnu"* ]]; then
    print_error "This script is designed for Linux systems"
    exit 1
fi

print_step "1. Checking system requirements..."

# Check Node.js
if ! command -v node &> /dev/null; then
    print_warning "Node.js not found. Installing Node.js 18..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
else
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 16 ]; then
        print_error "Node.js version 16+ required. Current: $(node --version)"
        exit 1
    fi
    print_status "Node.js $(node --version) found"
fi

# Check PostgreSQL
if ! command -v psql &> /dev/null; then
    print_warning "PostgreSQL not found. Installing PostgreSQL 14..."
    sudo apt update
    sudo apt install -y postgresql postgresql-contrib
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
else
    print_status "PostgreSQL found"
fi

# Check Redis
if ! command -v redis-cli &> /dev/null; then
    print_warning "Redis not found. Installing Redis..."
    sudo apt update
    sudo apt install -y redis-server
    sudo systemctl start redis-server
    sudo systemctl enable redis-server
else
    print_status "Redis found"
fi

print_step "2. Setting up project directories..."

# Create project structure if not exists
PROJECT_DIR="$(pwd)"
if [[ ! -f "$PROJECT_DIR/package.json" ]]; then
    print_error "Please run this script from the project root directory"
    exit 1
fi

print_step "3. Installing backend dependencies..."
cd backend
npm install

print_step "4. Setting up environment configuration..."

# Create .env file if not exists
if [[ ! -f ".env" ]]; then
    cp .env.example .env
    print_status "Created .env file from template"
    print_warning "Please edit backend/.env with your configuration before continuing"
    
    # Generate JWT secret
    JWT_SECRET=$(openssl rand -base64 32)
    sed -i "s/your-super-secret-jwt-key-change-this-in-production/$JWT_SECRET/" .env
    print_status "Generated JWT secret"
else
    print_status ".env file already exists"
fi

print_step "5. Setting up database..."

# Check if database exists
DB_NAME="whatsapp_ai"
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw $DB_NAME; then
    print_status "Database $DB_NAME already exists"
else
    print_status "Creating database $DB_NAME..."
    sudo -u postgres createdb $DB_NAME
    
    # Create user if not exists
    DB_USER="whatsapp_user"
    DB_PASS=$(openssl rand -base64 12)
    
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" 2>/dev/null || true
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    
    # Update .env with database credentials
    sed -i "s/DB_USER=postgres/DB_USER=$DB_USER/" .env
    sed -i "s/DB_PASSWORD=password/DB_PASSWORD=$DB_PASS/" .env
    
    print_status "Database user created: $DB_USER"
fi

print_step "6. Running database migrations..."
npm run migrate

print_step "7. Creating log directories..."
mkdir -p logs
chmod 755 logs

print_step "8. Setting up frontend..."
cd ../frontend

# Check if frontend directory exists and has package.json
if [[ -f "package.json" ]]; then
    npm install
    print_status "Frontend dependencies installed"
else
    print_warning "Frontend not set up yet. Will be created in Phase 5."
fi

cd ..

print_step "9. Setting up system services..."

# Create systemd service file
SERVICE_FILE="/etc/systemd/system/whatsapp-ai.service"
if [[ ! -f "$SERVICE_FILE" ]]; then
    sudo tee $SERVICE_FILE > /dev/null <<EOF
[Unit]
Description=WhatsApp AI System
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$PROJECT_DIR/backend
Environment=NODE_ENV=production
ExecStart=/usr/bin/node src/server.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    print_status "Systemd service created"
else
    print_status "Systemd service already exists"
fi

print_step "10. Setting up nginx (optional)..."
if command -v nginx &> /dev/null; then
    NGINX_CONFIG="/etc/nginx/sites-available/whatsapp-ai"
    if [[ ! -f "$NGINX_CONFIG" ]]; then
        sudo tee $NGINX_CONFIG > /dev/null <<EOF
server {
    listen 80;
    server_name your-domain.com;

    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF
        sudo ln -sf $NGINX_CONFIG /etc/nginx/sites-enabled/
        sudo nginx -t && sudo systemctl reload nginx
        print_status "Nginx configuration created"
    fi
else
    print_warning "Nginx not found. Install nginx for production deployment."
fi

print_step "11. Final setup..."

# Create startup script
cat > start.sh <<EOF
#!/bin/bash
echo "Starting WhatsApp AI System..."

# Start backend
cd backend
npm run dev &
BACKEND_PID=\$!

# Start frontend (if exists)
if [[ -f "../frontend/package.json" ]]; then
    cd ../frontend
    npm start &
    FRONTEND_PID=\$!
fi

echo "Backend PID: \$BACKEND_PID"
echo "Frontend PID: \$FRONTEND_PID"

echo "System started!"
echo "Backend: http://localhost:3000"
echo "Frontend: http://localhost:3001"

# Wait for Ctrl+C
trap 'kill \$BACKEND_PID \$FRONTEND_PID 2>/dev/null' EXIT
wait
EOF

chmod +x start.sh

echo ""
echo "============================================="
print_status "Installation completed successfully! 🎉"
echo "============================================="
echo ""
echo "📋 Next steps:"
echo "1. Edit backend/.env with your API keys:"
echo "   - WHATSAPP_API_KEY (360Dialog)"
echo "   - OPENAI_API_KEY"
echo ""
echo "2. Start the system:"
echo "   ./start.sh"
echo ""
echo "3. Access the dashboard:"
echo "   http://localhost:3001"
echo "   Email: admin@rbl.com"
echo "   Password: admin123"
echo ""
echo "📚 Documentation: README.md"
echo "🐛 Issues: Check logs in backend/logs/"
echo ""
print_status "Happy coding! 🚀"

