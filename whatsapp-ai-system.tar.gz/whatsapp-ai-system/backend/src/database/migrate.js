const fs = require('fs');
const path = require('path');
const { pool } = require('../config/database');
const logger = require('../utils/logger');

async function runMigration() {
  try {
    logger.info('🚀 Starting database migration...');

    // Read schema file
    const schemaPath = path.join(__dirname, '../../database/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');

    // Execute schema
    await pool.query(schema);

    logger.info('✅ Database migration completed successfully!');
    
    // Test connection
    const result = await pool.query('SELECT COUNT(*) FROM users');
    logger.info(`👥 Users table has ${result.rows[0].count} records`);

    process.exit(0);
  } catch (error) {
    logger.error('❌ Database migration failed:', error);
    process.exit(1);
  }
}

// Run migration if called directly
if (require.main === module) {
  runMigration();
}

module.exports = runMigration;

