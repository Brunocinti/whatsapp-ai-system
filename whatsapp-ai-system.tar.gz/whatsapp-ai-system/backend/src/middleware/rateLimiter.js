const { RateLimiterRedis } = require('rate-limiter-flexible');
const Redis = require('redis');
const config = require('../config');
const logger = require('../utils/logger');

// Create Redis client
const redisClient = Redis.createClient({
  host: config.redis.host,
  port: config.redis.port,
  password: config.redis.password,
});

redisClient.on('error', (err) => {
  logger.error('Redis Client Error:', err);
});

redisClient.on('connect', () => {
  logger.info('🔴 Connected to Redis');
});

// Rate limiter for general API requests
const rateLimiter = new RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'middleware',
  points: config.rateLimiting.max, // Number of requests
  duration: config.rateLimiting.windowMs / 1000, // Per duration in seconds
});

// Rate limiter for WhatsApp webhook (higher limit)
const whatsappRateLimiter = new RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'whatsapp',
  points: 1000, // Higher limit for WhatsApp webhooks
  duration: 60, // Per minute
});

// Rate limiter for AI requests (lower limit due to cost)
const aiRateLimiter = new RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'ai',
  points: 50, // Lower limit for AI requests
  duration: 60, // Per minute
});

const rateLimiterMiddleware = async (req, res, next) => {
  try {
    // Choose appropriate rate limiter based on route
    let limiter = rateLimiter;
    
    if (req.path.startsWith('/api/whatsapp/webhook')) {
      limiter = whatsappRateLimiter;
    } else if (req.path.startsWith('/api/ai')) {
      limiter = aiRateLimiter;
    }

    await limiter.consume(req.ip);
    next();
  } catch (rejRes) {
    const secs = Math.round(rejRes.msBeforeNext / 1000) || 1;
    
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`, {
      path: req.path,
      method: req.method,
      retryAfter: secs
    });

    res.set('Retry-After', String(secs));
    res.status(429).json({
      success: false,
      error: 'Too many requests, please try again later.',
      retryAfter: secs
    });
  }
};

module.exports = rateLimiterMiddleware;

