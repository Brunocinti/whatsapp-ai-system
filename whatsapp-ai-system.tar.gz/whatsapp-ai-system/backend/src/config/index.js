require('dotenv').config();

const config = {
  // Server
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  
  // Database
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    name: process.env.DB_NAME || 'whatsapp_ai',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password',
  },
  
  // Redis
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD || '',
  },
  
  // JWT
  jwt: {
    secret: process.env.JWT_SECRET || 'your-super-secret-jwt-key',
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  },
  
  // WhatsApp (360Dialog)
  whatsapp: {
    apiUrl: process.env.WHATSAPP_API_URL || 'https://waba.360dialog.io',
    apiKey: process.env.WHATSAPP_API_KEY || '',
    webhookSecret: process.env.WHATSAPP_WEBHOOK_SECRET || '',
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
  },
  
  // OpenAI
  openai: {
    apiKey: process.env.OPENAI_API_KEY || '',
    model: process.env.OPENAI_MODEL || 'gpt-4',
    maxTokens: parseInt(process.env.OPENAI_MAX_TOKENS) || 1000,
  },
  
  // Thaiza AI Configuration
  thaiza: {
    personality: 'Você é Thaiza Vianna, gerente da RBL FACTA especializada em FGTS e empréstimos.',
    temperature: 0.7,
    systemPrompt: `Você é a Thaiza Vianna, vendedora expert da RBL FACTA.
    
PERSONALIDADE:
- Tom caloroso mas profissional
- Usa emojis estrategicamente (🤩, 🌹, ☺️, 💗)
- Sempre menciona o nome do cliente
- Linguagem acessível e direta

PRODUTOS:
- Antecipação de FGTS (produto principal)
- Empréstimo Consignado CLT (9 meses carteira mínimo)

PROCESSO DE ATENDIMENTO (10 ETAPAS):
1. Apresentação inicial ou follow-up
2. Processo de autorização no app FGTS
3. Coleta de CPF e data nascimento
4. Apresentação do resultado com entusiasmo
5. Confirmação/coleta de dados bancários
6. Geração do link de saque
7. Solicitação de prioridade na análise
8. Finalização com agradecimento
9. Campanha de indicação
10. Oferta de consignado (opcional)

FRASES EXATAS:
- "Boas notícias!!!! Disponível para recebimento o valor de: *R$ [valor]*"
- "Vamos dar andamento ao saque? 🤩"
- "Um momento, por favor, que vou gerar o link de saque 👩‍💻"
- "Que ótimo! Seu pagamento foi emitido com sucesso!!! 🤩"

SEMPRE seguir o padrão exato das conversas reais fornecidas.`,
  },
  
  // Campaign Settings
  campaigns: {
    maxDailyMessages: parseInt(process.env.MAX_DAILY_MESSAGES) || 500,
    workingHours: {
      start: parseInt(process.env.WORKING_HOURS_START) || 7,
      end: parseInt(process.env.WORKING_HOURS_END) || 20,
    },
    workingDays: [1, 2, 3, 4, 5], // Monday to Friday
  },
  
  // Rate Limiting
  rateLimiting: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
  },
  
  // File Upload
  upload: {
    maxFileSize: 10 * 1024 * 1024, // 10MB
    allowedTypes: ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
  },
  
  // Bank Integration
  bank: {
    timeout: 30000, // 30 seconds
    retryAttempts: 3,
    headless: process.env.NODE_ENV === 'production',
  },
};

module.exports = config;

