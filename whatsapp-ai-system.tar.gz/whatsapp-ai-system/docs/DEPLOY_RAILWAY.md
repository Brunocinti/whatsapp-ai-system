# 🚀 Deploy no Railway - Guia Completo

## 📋 Pré-requisitos

- Conta no GitHub
- Conta no Railway (gratuita)
- Chave da OpenAI API

## 🎯 Passo a Passo

### **1. Preparar o Repositório GitHub**

#### Opção A: Criar novo repositório
```bash
# No GitHub, criar novo repositório "whatsapp-ai-system"
# Depois executar:
git init
git add .
git commit -m "Initial commit - WhatsApp AI System"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/whatsapp-ai-system.git
git push -u origin main
```

#### Opção B: Fork do repositório existente
- Fazer fork do repositório
- Clonar localmente
- Fazer suas modificações

### **2. Configurar Railway**

#### 2.1. Criar conta
1. Acesse: https://railway.app
2. Faça login com GitHub
3. Você ganha $5 grátis por mês

#### 2.2. Criar novo projeto
1. Clique em "New Project"
2. Selecione "Deploy from GitHub repo"
3. Escolha o repositório "whatsapp-ai-system"
4. Railway detectará automaticamente o Node.js

### **3. Configurar Banco de Dados**

#### 3.1. Adicionar PostgreSQL
1. No dashboard do projeto, clique em "New"
2. Selecione "Database" → "Add PostgreSQL"
3. Railway criará automaticamente as variáveis:
   - `DATABASE_URL`
   - `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`

#### 3.2. Adicionar Redis
1. Clique em "New" → "Database" → "Add Redis"
2. Railway criará automaticamente:
   - `REDIS_URL`
   - `REDISHOST`, `REDISPORT`, `REDISPASSWORD`

### **4. Configurar Variáveis de Ambiente**

No dashboard do Railway, vá em "Variables" e adicione:

```env
# Obrigatórias
NODE_ENV=production
PORT=3000
JWT_SECRET=seu-jwt-secret-super-seguro

# OpenAI (OBRIGATÓRIA)
OPENAI_API_KEY=sk-sua-chave-openai-aqui

# WhatsApp (configurar depois)
WHATSAPP_API_URL=https://waba.360dialog.io
WHATSAPP_API_KEY=sua-chave-360dialog
WHATSAPP_PHONE_NUMBER_ID=seu-phone-number-id
WHATSAPP_WEBHOOK_SECRET=seu-webhook-secret

# Configurações de campanha
MAX_DAILY_MESSAGES=500
WORKING_HOURS_START=7
WORKING_HOURS_END=20
```

### **5. Deploy Automático**

1. Railway fará deploy automático quando você fizer push
2. Acompanhe os logs no dashboard
3. Aguarde o deploy completar (2-5 minutos)

### **6. Executar Migração do Banco**

Após o primeiro deploy:

1. No Railway dashboard, vá em "Deployments"
2. Clique nos 3 pontos → "View Logs"
3. Ou execute via Railway CLI:

```bash
# Instalar Railway CLI
npm install -g @railway/cli

# Login
railway login

# Conectar ao projeto
railway link

# Executar migração
railway run npm run migrate
```

### **7. Testar o Sistema**

1. Acesse a URL fornecida pelo Railway
2. Teste o endpoint de saúde: `https://sua-url.railway.app/health`
3. Deve retornar: `{"status":"OK","timestamp":"...","version":"1.0.0"}`

### **8. Configurar 360Dialog**

#### 8.1. Criar conta 360Dialog
1. Acesse: https://360dialog.com
2. Crie conta e solicite número WhatsApp Business
3. Obtenha as credenciais da API

#### 8.2. Configurar Webhook
1. No painel 360Dialog, configure o webhook:
2. URL: `https://sua-url.railway.app/api/whatsapp/webhook`
3. Secret: o valor da variável `WHATSAPP_WEBHOOK_SECRET`

#### 8.3. Atualizar variáveis no Railway
```env
WHATSAPP_API_KEY=sua-chave-360dialog
WHATSAPP_PHONE_NUMBER_ID=seu-phone-number-id
```

### **9. Monitoramento**

#### 9.1. Logs
- Acesse logs em tempo real no dashboard Railway
- Ou via CLI: `railway logs`

#### 9.2. Métricas
- CPU, RAM e Network no dashboard
- Alertas automáticos por email

#### 9.3. Health Check
- Railway monitora automaticamente `/health`
- Restart automático se necessário

## 🔧 Comandos Úteis

```bash
# Ver status do projeto
railway status

# Ver logs em tempo real
railway logs

# Executar comando no servidor
railway run node -v

# Abrir shell no servidor
railway shell

# Ver variáveis de ambiente
railway variables

# Fazer redeploy
git push origin main
```

## 🚨 Troubleshooting

### Deploy falha
1. Verifique os logs no dashboard
2. Confirme se todas as variáveis estão configuradas
3. Teste localmente com Docker

### Banco não conecta
1. Verifique se PostgreSQL foi adicionado
2. Confirme as variáveis de banco
3. Execute a migração manualmente

### WhatsApp não funciona
1. Verifique credenciais 360Dialog
2. Confirme URL do webhook
3. Teste endpoint webhook manualmente

## 💰 Custos

### Railway Gratuito
- $5 grátis por mês
- Suficiente para ~500-1000 mensagens/mês
- Ideal para testes

### Railway Pro ($20/mês)
- $20 de crédito por mês
- Suficiente para ~10k-50k mensagens/mês
- Ideal para produção

### 360Dialog
- €49/mês + custos por mensagem
- Ver documentação de preços

## 🎉 Resultado Final

Após completar todos os passos:

✅ Sistema funcionando 24/7 na nuvem
✅ Banco PostgreSQL configurado
✅ Redis para cache e filas
✅ WhatsApp API integrada
✅ IA OpenAI funcionando
✅ Logs e monitoramento
✅ Deploy automático via Git

**URL do sistema**: `https://sua-url.railway.app`
**Admin**: admin@rbl.com / admin123

## 📞 Suporte

- Railway: https://railway.app/help
- 360Dialog: https://docs.360dialog.com
- OpenAI: https://platform.openai.com/docs

---

**🚀 Sistema pronto para receber milhares de clientes!**

